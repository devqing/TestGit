"scene_reco_tags":{
    "title" : "你想住哪个区域",
    "bgcolor" : "FFE59C",
    "position" : 9,
    "type" : 0,
    "case_id" : "case8",
    "tags" : [
    {
        "tag_name" : "荣泽家园",
        "tag_scheme" : "c1111047349969"
    },{
        "tag_name" : "4000起",
        "tag_scheme" : "rp3"
    },{
        "tag_name" : "西二旗",
        "tag_scheme" : "xierqi/"
    },{
        "tag_name" : "4000-5000",
        "tag_scheme" : "erp4000brp5000"
    }
              
    ]
},


"scene_reco_tags": {
    "title": "\u60a8\u60f3\u4f4f\u5728\u54ea\u4e2a\u533a\u57df",
    "bgcolor": "FFE59C",
    "position": 9,
    "tags": [{
        "tag_name": "\u4e1c\u57ce",
        "tag_desc": "",
        "tag_scheme": "dongcheng\/",
        "eleid": "010AC8242589FD660373017901452231_2eef877abd9dfaa7f4e8ee423cef9b83"
    }, {
        "tag_name": "\u897f\u57ce",
        "tag_desc": "",
        "tag_scheme": "xicheng\/",
        "eleid": "010AC8242589FD660373017901452231_29eafc13add162f0d180d3a59c41b44f"
    }, {
        "tag_name": "\u671d\u9633",
        "tag_desc": "",
        "tag_scheme": "chaoyang\/",
        "eleid": "010AC8242589FD660373017901452231_5bf4fad5126543929926901cd1a549b1"
    }, {
        "tag_name": "\u6d77\u6dc0",
        "tag_desc": "",
        "tag_scheme": "haidian\/",
        "eleid": "010AC8242589FD660373017901452231_dfac09520187b9fda91bfe6610d0a3c6"
    }, {
        "tag_name": "\u4e30\u53f0",
        "tag_desc": "",
        "tag_scheme": "fengtai\/",
        "eleid": "010AC8242589FD660373017901452231_286bd3123718e96338cf0ba9ccb80e50"
    }, {
        "tag_name": "\u77f3\u666f\u5c71",
        "tag_desc": "",
        "tag_scheme": "shijingshan\/",
        "eleid": "010AC8242589FD660373017901452231_b71f541bb6353c34fac111b01772b23c"
    }],
    "type": 0
},
